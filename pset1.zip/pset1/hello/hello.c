//Abrimos la libreria
#include <stdio.h>

//Declaramos a la funcion principal
int main(void)
{
    //Dice "Hola Mundo"
    printf("hello, world\n");

    //Le decimos al programa que concluyo todo
    return 0;
}